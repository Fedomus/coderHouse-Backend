function getRoot(req, res) {
      res.render('pages/index.ejs', {loggedUser: false, loggedAdmin: false, email: null})
}

function getSignup(req, res) {
      res.render('pages/signup.ejs')
}

function postSignup (req, res) {
      res.redirect('/')
}

function getFailsignup (req, res) {
      console.log('error en signup');
      res.render('pages/signup-error.ejs', {});
}

function postLogin (req, res) {
      res.redirect('/profile')
}

function getFaillogin (req, res) {
      console.log('error en login');
      res.render('pages/login-error.ejs', {});
}

function getProfile(req, res){
      res.render('pages/index.ejs', {loggedUser: true, loggedAdmin: false, username: req.session.email})
}

function getLogout (req, res) {
      let email = req.session.email;
      req.logout( (err) => {
            if (!err) {
                  res.render('pages/index.ejs', {loggedUser: false, loggedAdmin: false, email: username})
            } 
      });
}

function failRoute(req, res){
      res.status(404).render('pages/routing-error.ejs', {});
}

function checkAuthentication(req, res, next) {
      if (req.isAuthenticated()) {
            next();
      } else {
            res.redirect("/");
      }
}


module.exports = {getRoot, getSignup, postSignup, getFailsignup, postLogin, getFaillogin, getProfile, getLogout, failRoute, checkAuthentication}